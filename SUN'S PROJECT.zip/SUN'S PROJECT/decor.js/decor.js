const boxinner = document.querySelector(".boxTwoInternal");

for(let i=0;i<5;i++){
    boxinner.innerHTML+=boxinner.innerHTML;
}

